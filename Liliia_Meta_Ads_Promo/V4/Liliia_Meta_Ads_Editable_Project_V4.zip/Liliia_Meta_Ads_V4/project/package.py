from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'Liliia_Meta_Ads_Editable_Project_V4.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for name in ['README_RU.md','requirements.txt']:z.write(R/name,'Liliia_Meta_Ads_V4/'+name)
 for name in ['source','project','music','assets','end-card','review']:
  for f in (R/name).rglob('*'):
   if not f.is_file() or '__pycache__' in f.parts or f.name=='analysis.wav':continue
   z.write(f,'Liliia_Meta_Ads_V4/'+str(f.relative_to(R)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for f in ['project/design.json','project/render.py','end-card/component.json','end-card/End_Card.svg','music/CREDITS.txt','music/Realizer.mp3']:assert 'Liliia_Meta_Ads_V4/'+f in z.namelist()
print('Verified project ZIP',out,round(out.stat().st_size/1024**2,1),'MiB')
