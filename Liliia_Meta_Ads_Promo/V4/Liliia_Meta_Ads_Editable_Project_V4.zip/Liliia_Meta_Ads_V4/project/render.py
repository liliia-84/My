"""Editable Meta Ads preview. Keep V2 structure; replace the interior-heavy section with real working details."""
from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[1];E=json.loads((R/'project/design.json').read_text());C=R/'intermediates';C.mkdir(exist_ok=True)
def run(a):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*a],check=True)
base=['-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','2','-r','30','-fps_mode','cfr','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709']
if '--finish' not in sys.argv:
 subprocess.run([sys.executable,str(R/'project/build_picture.py')],check=True)
 subprocess.run([sys.executable,str(R/'project/build_assets.py')],check=True)
 # Main picture preserves V2 outside timeline 7.2–11.067; notes use a gentle 0.75x hold.
 a=['-threads','1','-i',str(R/'intermediates/working-picture.mov')]
 for i,t in enumerate(E['titles']):a+=['-loop','1','-framerate','30','-t',str(t['end']+.1),'-i',str(R/'assets'/f'title-{i+1}.png')]
 f=['[0:v]setpts=N/(30*TB),setsar=1[base]'];last='base'
 for i,t in enumerate(E['titles']):
  st=t['start'];en=min(t['end'],E['end_card']['start']);out=en-t['fade_out']
  f.append(f'[{i+1}:v]format=rgba,fade=t=in:st={st}:d={t['fade_in']}:alpha=1,fade=t=out:st={out}:d={t['fade_out']}:alpha=1[title{i}]')
  f.append(f"[{last}][title{i}]overlay=x=0:y='{t['y']-90}+6*(1-min(max((t-{st})/{t['fade_in']},0),1))':format=auto:enable='between(t,{st},{en})'[p{i}]");last=f'p{i}'
 f.append(f'[{last}]format=yuv420p[out]')
 print('Rendering V4 titles over the targeted work-shot edit',flush=True)
 run([*a,'-filter_complex',';'.join(f),'-filter_complex_threads','1','-map','[out]','-an','-frames:v','451',*base,str(C/'main.mov')])
 card=E['end_card'];duration=card['duration'];fade=duration-card['fade_out']
 print('Rendering reusable End Card',flush=True)
 run(['-loop','1','-framerate','30','-i',str(R/'end-card/background.png'),'-loop','1','-framerate','30','-i',str(R/'end-card/type-overlay.png'),'-filter_complex',f'[1:v]format=rgba,fade=t=in:st=0:d={card["fade_in"]}:alpha=1,fade=t=out:st={fade}:d={card["fade_out"]}:alpha=1[t];[0:v][t]overlay,format=yuv420p[v]','-filter_complex_threads','1','-map','[v]','-an','-frames:v','95',*base,'-movflags','+faststart',str(R/'end-card/Liliia_Meta_Ads_End_Card.mp4')])
print('Soft brand transition; finishing licensed music',flush=True)
card=E['end_card'];m=E['music'];total=E['output_frames']/30
flt=f'[0:v]fps=30,settb=1/30,setsar=1[a];[1:v]fps=30,settb=1/30,setsar=1[b];[a][b]xfade=transition=fade:duration={card["transition"]}:offset={card["start"]},fps=30,format=yuv420p[v]'
credit='Music: Realizer - Kevin MacLeod (incompetech.com), CC BY 4.0 https://creativecommons.org/licenses/by/4.0/ ; excerpt trimmed, volume adjusted and faded.'
run(['-i',str(C/'main.mov'),'-i',str(R/'end-card/Liliia_Meta_Ads_End_Card.mp4'),'-i',str(R/m['cached_aac']),'-filter_complex',flt,'-filter_complex_threads','1','-map','[v]','-map','2:a:0','-frames:v',str(E['output_frames']),'-t',str(total),*base,'-c:a','copy','-metadata','title=Liliia Meta Ads Promo - Preview V4','-metadata','comment='+credit,'-movflags','+faststart',str(R/'Liliia_Meta_Ads_Promo_Preview_V4.mp4')])
print('Complete:',total,'seconds',flush=True)
