# Liliia Meta Ads Promo — Preview V1

1080×1920 · 30 fps · 18.033 seconds · H.264 / AAC stereo 48 kHz. This is a review preview, not an approved final advertising export.

The original 15.033-second edit is preserved, in its original order and at its original speed. All 451 source frames remain in the main composition. The final 0.3 seconds dissolve into the reusable End Card; the overall output has 541 frames. No color grade, beauty filter, face alteration, or extra scenes were applied. The original MOV is unchanged and verified against its source SHA-256.

## Text and layout

0.1–3.0: «Вашему бизнесу нужны клиенты?»
3.0–7.0: «Запущу рекламу в Instagram и Facebook»
7.0–11.0: «От стратегии — к целевым заявкам»
11.0–14.733: «Давайте развивать ваш бизнес!»

Montserrat variable font with Cyrillic, moderate semibold weight, white plus #E6A5C2 accents. The first highlighted word and platform names are pink; «целевым заявкам» has a subtle pink underline. Soft translucent shadows and 0.3-second fades with a gentle 10px rise; no panels, frames, or character effects. The final video title is below the face. All text fits x=100..980 and y=250..1500; measured final bottom is1433. Individual Meta placements can show different interface overlays; review the placement preview before publishing.

## Reusable End Card

`end-card/component.json` is the editable component: name, role, offer, CTA, handle, font, color, size, and position are separate fields.
`end-card/End_Card.svg` is an editable vector version; use bundled Montserrat. `End_Card.png` is the full-resolution reference. `Liliia_Meta_Ads_End_Card.mp4` is the independent 3.3-second animated video with a 0.4-second appearance, 2.5-second hold and 0.4-second exit. The first 0.3 seconds overlap the main clip, adding exactly 3 seconds to the full preview. The graphite/plum background remains through the last frame.

## Music and advertising license

“Realizer” — Kevin MacLeod (incompetech.com), CC BY 4.0. This license permits commercial use and adaptation, including music synchronized to paid advertising, with attribution and a modification notice. Copy `music/CREDITS.txt`'s attribution block into the ad caption/description. Music credit is not placed over the brand End Card.

The author page, author catalog metadata, full original MP3, SHA-256, archived license deed and newly retrieved official CC BY 4.0 legal code are in `music/`. The previously acquired licensed master was used because the author's server returned HTTP503 for new track downloads during this task. No unlicensed replacement was used. Excerpt: 62.094s onward, 125 BPM, the End Card begins on a phrase downbeat. The music has a one-second final fade. The promo uses the licensed music bed rather than the source MOV's audio.

## Edit and rebuild

Create a Python 3 virtual environment and install `requirements.txt`. FFmpeg/ffprobe must be available. Run:

```
python project/render.py
python project/validate.py
```

Change `project/design.json` for title text, timings, color, typography and music settings; change `end-card/component.json` for the End Card. `project/build_assets.py` regenerates all PNG/SVG assets. The font and OFL license are included. Render scripts rebuild only this preview and standalone End Card; source MOV and other projects are not modified.
