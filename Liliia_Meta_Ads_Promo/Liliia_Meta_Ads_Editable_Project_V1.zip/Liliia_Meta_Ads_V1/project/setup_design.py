from pathlib import Path
import json,shutil,hashlib
R=Path(__file__).resolve().parents[1]
config={'width':1080,'height':1920,'fps':30,'source':'source/copy_3F0D5B63-149D-42D0-871C-417F2F30640D.MOV','source_frames':451,'output_frames':541,'pink':'#E6A5C2','white':'#FFFFFF','font':'assets/Montserrat.ttf','weight':600,'titles':[
{'start':0.1,'end':3,'y':300,'size':80,'lines':[[['Вашему бизнесу','white']],[['нужны ','white'],['клиенты?','pink']]]},
{'start':3,'end':7,'y':300,'size':76,'lines':[[['Запущу рекламу','white']],[['в ','white'],['Instagram','pink']],[['и ','white'],['Facebook','pink']]]},
{'start':7,'end':11,'y':320,'size':72,'lines':[[['От стратегии —','white']],[['к ','white'],['целевым заявкам','white','underline']]]},
{'start':11,'end':14.733333333333333,'y':1210,'size':76,'lines':[[['Давайте развивать','white']],[['ваш бизнес!','white']]]}],
'music':{'file':'music/Realizer.mp3','source_start':62.094,'fade_in':.3,'fade_out':1,'loudness':-16,'bpm':125,'note':'End Card transition begins on phrase downbeat at source 76.827s. Music is faded across final 1 second.'},
'end_card':{'component':'end-card/component.json','duration':3.3,'transition':.3,'start':14.733333333333333,'fade_in':.4,'fade_out':.4}}
(R/'project/design.json').write_text(json.dumps(config,ensure_ascii=False,indent=2))
card={'background_top':'#211E27','background_bottom':'#2C2332','font':'assets/Montserrat.ttf','width':1080,'height':1920,'elements':[
{'text':'LILIIA KYCHENKO','y':505,'size':76,'weight':650,'color':'#FFFFFF'},
{'text':'META ADS SPECIALIST','y':620,'size':36,'weight':550,'tracking':3,'color':'#E6A5C2'},
{'text':'Хотите больше','y':845,'size':49,'weight':500,'color':'#FFFFFF'},
{'text':'целевых обращений?','y':911,'size':49,'weight':500,'color':'#FFFFFF'},
{'text':'Напишите «РЕКЛАМА»','y':1105,'size':62,'weight':650,'color':'#E6A5C2'},
{'text':'в Direct','y':1183,'size':62,'weight':650,'color':'#FFFFFF'},
{'text':'@target.with.liliia','y':1390,'size':43,'weight':550,'color':'#E6A5C2'}]}
(R/'end-card/component.json').write_text(json.dumps(card,ensure_ascii=False,indent=2))
old=Path('/workspace/legacy-girls-night/v8/music')
for src,dst in [('Realizer.mp3','Realizer.mp3'),('official-track-page.html','author-track-page-archived.html'),('official-catalog.json','author-catalog-archived.json'),('CC-BY-4.0.html','CC-BY-4.0-deed-archived.html')]:shutil.copy2(old/src,R/'music'/dst)
track=next(x for x in json.loads((old/'official-catalog.json').read_text()) if x['title']=='Realizer')
track.update(source_url='https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1900024',download_url='https://incompetech.com/music/royalty-free/mp3-royaltyfree/Realizer.mp3',license='CC BY 4.0',license_url='https://creativecommons.org/licenses/by/4.0/',paid_ad_use='CC BY 4.0 permits commercial reproduction, sharing and adaptation, including synchronization in advertising, with attribution and modification notice. No NC restriction.',sha256=hashlib.sha256((R/'music/Realizer.mp3').read_bytes()).hexdigest(),evidence_note='Author source page and catalog archived during previous project; newly retrieved official CC legal code is also saved. The author site currently returns HTTP 503, so no unavailable new track is substituted.')
(R/'music/source.json').write_text(json.dumps(track,indent=2,ensure_ascii=False))
(R/'music/CREDITS.txt').write_text('Music: “Realizer” — Kevin MacLeod (incompetech.com)\nhttps://incompetech.com/music/royalty-free/index.html?isrc=USUAN1900024\nCC BY 4.0: https://creativecommons.org/licenses/by/4.0/\nExcerpt trimmed, volume-adjusted and faded for this advertisement.\n\nInclude the attribution above in the ad caption/description when publishing, and retain it with any reused copy. The music license permits commercial use; it does not imply artist endorsement of the advertised services.\n')
print('Editable design and licensed music prepared')
