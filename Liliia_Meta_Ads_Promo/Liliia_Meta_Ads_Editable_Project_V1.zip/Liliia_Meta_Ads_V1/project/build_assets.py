from pathlib import Path
import json,html
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
R=Path(__file__).resolve().parents[1];E=json.loads((R/'project/design.json').read_text());W,H=1080,1920;S=2
checks=[]
def font(size,weight=600):
 f=ImageFont.truetype(str(R/E['font']),round(size*S));f.set_variation_by_axes([weight]);return f
def draw_runs(img,lines,y,size):
 layer=Image.new('RGBA',(W*S,H*S));d=ImageDraw.Draw(layer);f=font(size)
 for ln in lines:
  width=sum(d.textlength(run[0],font=f) for run in ln);x=(W*S-width)/2
  assert x>=100*S and x+width<=980*S,(width/S,ln)
  checks.append({'text':''.join(v[0] for v in ln),'x':x/S,'y':y,'width':width/S,'height':size})
  for run in ln:
   col=E[run[1]];d.text((x,y*S),run[0],font=f,fill=col,anchor='lt');advance=d.textlength(run[0],font=f)
   if len(run)>2 and run[2]=='underline':d.rounded_rectangle((x,(y+size+9)*S,x+advance,(y+size+12)*S),radius=1*S,fill=E['pink'])
   x+=advance
  y+=size*1.23
 # Soft, translucent shadow without panels.
 alpha=layer.getchannel('A');shadow=Image.new('RGBA',layer.size,(0,0,0,0));shadow.putalpha(alpha.point(lambda a:int(a*.68)).filter(ImageFilter.GaussianBlur(2*S)))
 img.alpha_composite(shadow,(0,3*S));img.alpha_composite(layer)
for i,t in enumerate(E['titles']):
 im=Image.new('RGBA',(W*S,H*S));draw_runs(im,t['lines'],t['y'],t['size']);im.resize((W,H),Image.Resampling.LANCZOS).crop((0,int(t['y']-20),W,int(t['y']+len(t['lines'])*t['size']*1.23+35))).save(R/'assets'/f'title-{i+1}.png')
C=json.loads((R/'end-card/component.json').read_text())
def rgb(h):return np.array([int(h[i:i+2],16) for i in [1,3,5]])
a=rgb(C['background_top']);b=rgb(C['background_bottom']);arr=np.repeat(np.round(a[None,None,:]+(b-a)[None,None,:]*np.linspace(0,1,H*S)[:,None,None]).astype('uint8'),W*S,axis=1)
background=Image.fromarray(arr,'RGB').convert('RGBA');background.resize((W,H),Image.Resampling.LANCZOS).save(R/'end-card/background.png');card=background.copy();type_layer=Image.new('RGBA',card.size);d=ImageDraw.Draw(type_layer)
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920"><defs><style>@font-face {{font-family:Montserrat;src:url(../assets/Montserrat.ttf)}}</style><linearGradient id="bg" x2="0" y2="1"><stop stop-color="{C["background_top"]}"/><stop offset="1" stop-color="{C["background_bottom"]}"/></linearGradient></defs><rect width="1080" height="1920" fill="url(#bg)"/>']
for el in C['elements']:
 f=font(el['size'],el['weight']);text=el['text'];tracking=el.get('tracking',0)*S;width=d.textlength(text,font=f)+tracking*(len(text)-1);x=(W*S-width)/2
 assert x>=100*S and x+width<=980*S,(text,width/S)
 checks.append({'text':text,'x':x/S,'y':el['y'],'width':width/S,'height':el['size']})
 if tracking:
  for ch in text:d.text((x,el['y']*S),ch,font=f,fill=el['color'],anchor='lt');x+=d.textlength(ch,font=f)+tracking
 else:d.text((x,el['y']*S),text,font=f,fill=el['color'],anchor='lt')
 svg.append(f'<text x="540" y="{el["y"]}" text-anchor="middle" dominant-baseline="hanging" font-family="Montserrat,sans-serif" font-size="{el["size"]}" font-weight="{el["weight"]}" letter-spacing="{el.get("tracking",0)}" fill="{el["color"]}">{html.escape(text)}</text>')
card.alpha_composite(type_layer);card.resize((W,H),Image.Resampling.LANCZOS).save(R/'end-card/End_Card.png');svg.append('</svg>');(R/'end-card/End_Card.svg').write_text('\n'.join(svg));type_layer.resize((W,H),Image.Resampling.LANCZOS).save(R/'end-card/type-overlay.png')
(R/'project/text-bounds.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print('Assets built, all text within horizontal safe bounds. Max bottom:',max(x['y']+x['height'] for x in checks))
