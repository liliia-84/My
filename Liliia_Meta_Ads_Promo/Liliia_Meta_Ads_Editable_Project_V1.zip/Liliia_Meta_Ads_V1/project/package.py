from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'Liliia_Meta_Ads_Editable_Project_V1.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for name in ['README.md','README_RU.md','requirements.txt']:z.write(R/name,'Liliia_Meta_Ads_V1/'+name)
 for name in ['source','project','music','assets','end-card','review']:
  for f in (R/name).rglob('*'):
   if not f.is_file() or '__pycache__' in f.parts or f.name=='analysis.wav':continue
   if f.name=='drive-folder.html':continue
   z.write(f,'Liliia_Meta_Ads_V1/'+str(f.relative_to(R)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for f in ['source/copy_3F0D5B63-149D-42D0-871C-417F2F30640D.MOV','project/render.py','project/design.json','end-card/component.json','end-card/End_Card.svg','music/Realizer.mp3','music/CREDITS.txt']:assert 'Liliia_Meta_Ads_V1/'+f in z.namelist()
print('Verified editable project:',out,round(out.stat().st_size/1024**2,1),'MiB')
