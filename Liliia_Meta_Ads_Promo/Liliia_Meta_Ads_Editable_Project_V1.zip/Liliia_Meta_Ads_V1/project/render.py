"""Editable Meta Ads preview. Preserve all 451 source frames; add timed overlays and reusable End Card."""
from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[1];E=json.loads((R/'project/design.json').read_text());C=R/'intermediates';C.mkdir(exist_ok=True)
def run(a):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*a],check=True)
base=['-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','2','-r','30','-fps_mode','cfr','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709']
if '--finish' not in sys.argv:
 subprocess.run([sys.executable,str(R/'project/build_assets.py')],check=True)
 # Main picture: no source cut, reordering, speed or color changes.
 a=['-threads','1','-i',str(R/E['source'])]
 for i in range(4):a+=['-loop','1','-framerate','30','-i',str(R/'assets'/f'title-{i+1}.png')]
 f=['[0:v]setpts=N/(30*TB),setsar=1[base]'];last='base'
 for i,t in enumerate(E['titles']):
  st=t['start'];en=min(t['end'],E['end_card']['start']);out=en-.18
  f.append(f'[{i+1}:v]format=rgba,fade=t=in:st={st}:d=0.3:alpha=1,fade=t=out:st={out}:d=0.18:alpha=1[title{i}]')
  f.append(f"[{last}][title{i}]overlay=x=0:y='{t['y']-20}+10*(1-min(max((t-{st})/0.3,0),1))':format=auto:enable='between(t,{st},{en})'[p{i}]");last=f'p{i}'
 f.append(f'[{last}]format=yuv420p[out]')
 print('Rendering main picture, source montage preserved',flush=True)
 run([*a,'-filter_complex',';'.join(f),'-filter_complex_threads','1','-map','[out]','-an','-frames:v','451',*base,str(C/'main.mov')])
 card=E['end_card'];duration=card['duration'];fade=duration-card['fade_out']
 print('Rendering reusable End Card',flush=True)
 run(['-loop','1','-framerate','30','-i',str(R/'end-card/background.png'),'-loop','1','-framerate','30','-i',str(R/'end-card/type-overlay.png'),'-filter_complex',f'[1:v]format=rgba,fade=t=in:st=0:d={card["fade_in"]}:alpha=1,fade=t=out:st={fade}:d={card["fade_out"]}:alpha=1[t];[0:v][t]overlay,format=yuv420p[v]','-filter_complex_threads','1','-map','[v]','-an','-frames:v','99',*base,'-movflags','+faststart',str(R/'end-card/Liliia_Meta_Ads_End_Card.mp4')])
print('Soft brand transition; finishing licensed music',flush=True)
card=E['end_card'];m=E['music'];total=E['output_frames']/30
flt=f'[0:v]fps=30,settb=1/30,setsar=1[a];[1:v]fps=30,settb=1/30,setsar=1[b];[a][b]xfade=transition=fade:duration={card["transition"]}:offset={card["start"]},fps=30,format=yuv420p[v];[2:a]atrim=duration={total},asetpts=PTS-STARTPTS,loudnorm=I={m["loudness"]}:TP=-1.5:LRA=7,afade=t=in:d={m["fade_in"]},afade=t=out:st={total-m["fade_out"]}:d={m["fade_out"]},aresample=48000[audio]'
credit='Music: Realizer - Kevin MacLeod (incompetech.com), CC BY 4.0 https://creativecommons.org/licenses/by/4.0/ ; excerpt trimmed, volume adjusted and faded.'
run(['-i',str(C/'main.mov'),'-i',str(R/'end-card/Liliia_Meta_Ads_End_Card.mp4'),'-ss',str(m['source_start']),'-i',str(R/m['file']),'-filter_complex',flt,'-filter_complex_threads','1','-map','[v]','-map','[audio]','-frames:v',str(E['output_frames']),'-t',str(total),*base,'-c:a','aac','-b:a','256k','-ar','48000','-ac','2','-metadata','title=Liliia Meta Ads Promo - Preview V1','-metadata','comment='+credit,'-movflags','+faststart',str(R/'Liliia_Meta_Ads_Promo_Preview_V1.mp4')])
print('Complete:',total,'seconds',flush=True)
