from pathlib import Path
import json,subprocess,hashlib,math
R=Path(__file__).resolve().parents[1];p=R/'Liliia_Meta_Ads_Promo_Preview_V3.mp4';E=json.loads((R/'project/design.json').read_text())
def probe(f):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(f)]))
q=probe(p);v=next(s for s in q['streams'] if s['codec_type']=='video');a=next(s for s in q['streams'] if s['codec_type']=='audio');assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==('h264',1080,1920,'30/1','541');assert a['codec_name']=='aac' and a['sample_rate']=='48000';assert abs(float(q['format']['duration'])-541/30)<.04
main=probe(R/'intermediates/main.mov');assert next(s for s in main['streams'] if s['codec_type']=='video')['nb_frames']=='451'
c=probe(R/'end-card/Liliia_Meta_Ads_End_Card.mp4');assert next(s for s in c['streams'] if s['codec_type']=='video')['nb_frames']=='95'
m=json.loads((R/'project/source-manifest.json').read_text());assert hashlib.sha256((R/E['source']).read_bytes()).hexdigest()==m['sha256']
for f,h in json.loads((R/'project/previous-checksums.json').read_text()).items():
 if Path(f).exists():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
for b in json.loads((R/'project/text-bounds.json').read_text()):assert b['x']>=100 and b['x']+b['width']<=980 and b['y']>=250 and b['y']+b['height']<1500
frames=[15,43,75,135,230,267,306,390,451,480,510,536];expr='+'.join(f'eq(n,{n})' for n in frames)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(p),'-vf',f"select='{expr}',scale=270:480,tile=4x3",'-frames:v','1',str(R/'review/finished-contact.jpg')],check=True)
for name,t in [('opening',.5),('laptop-title',4.5),('strategy-title',8.5),('camera-title',12.5),('end-card-readable',16)]:
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(t),'-i',str(p),'-vf','scale=432:768','-frames:v','1',str(R/'review'/f'{name}.jpg')],check=True)
audio_ref=subprocess.check_output(['ffmpeg','-v','error','-i',str(R/E['music']['cached_aac']),'-vn','-c:a','copy','-f','adts','-'])
audio_out=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-vn','-c:a','copy','-f','adts','-'])
assert hashlib.sha256(audio_ref).digest()==hashlib.sha256(audio_out).digest(), 'Music packet content changed'
(R/'project/validation.json').write_text(json.dumps({'result':'PASS','preview':q,'source_sha256_unchanged':m['sha256'],'main_picture_frame_count':451,'end_card_frames':95,'output_frames':541,'safe_text_bounds':'x 100..980, y250..1500; measured bottom1390'},indent=2));print('PASS: 18.033 seconds, 541 frames, source 451-frame duration maintained; targeted work-shot replacement, H264/AAC, safe text bounds, unchanged original.')
