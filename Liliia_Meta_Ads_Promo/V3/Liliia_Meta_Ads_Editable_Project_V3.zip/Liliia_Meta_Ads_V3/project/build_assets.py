from pathlib import Path
import json,html
from PIL import Image,ImageDraw,ImageFont,ImageFilter
R=Path(__file__).resolve().parents[1];E=json.loads((R/'project/design.json').read_text());W,H,S=1080,1920,2;checks=[]
def font(size,weight):
 f=ImageFont.truetype(str(R/E['font']),round(size*S));f.set_variation_by_axes([weight]);return f
def text(d,t,y,size,weight,color):
 f=font(size,weight);width=d.textlength(t,font=f);x=(W*S-width)/2
 assert 110*S<=x and x+width<=970*S,(t,width/S)
 d.text((x,y*S),t,font=f,fill=color,anchor='lt');checks.append({'text':t,'x':x/S,'y':y,'width':width/S,'height':size})
for i,t in enumerate(E['titles']):
 layer=Image.new('RGBA',(W*S,H*S));d=ImageDraw.Draw(layer);y=t['y']
 for ln in t['lines']:
  text(d,ln['text'],y,ln['size'],ln['weight'],E[ln['color']]);y+=ln['size']*1.24+8
 alpha=layer.getchannel('A');shadow=Image.new('RGBA',layer.size);shadow.putalpha(alpha.point(lambda a:int(a*.75)).filter(ImageFilter.GaussianBlur(2*S)));im=Image.new('RGBA',layer.size);im.alpha_composite(shadow,(0,3*S));im.alpha_composite(layer)
 
 if t.get('local_shade'):
  shade=Image.new('RGBA',im.size);sd=ImageDraw.Draw(shade);sd.ellipse((80*S,(t['y']-35)*S,1000*S,(y+20)*S),fill=(0,0,0,100));shade=shade.filter(ImageFilter.GaussianBlur(55*S));shade.alpha_composite(im);im=shade
 im.resize((W,H),Image.Resampling.LANCZOS).crop((0,int(t['y']-90),W,int(y+90))).save(R/'assets'/f'title-{i+1}.png')
C=json.loads((R/'end-card/component.json').read_text());bg=Image.new('RGBA',(W*S,H*S),C['background']);bg.resize((W,H)).save(R/'end-card/background.png');layer=Image.new('RGBA',bg.size);d=ImageDraw.Draw(layer)
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920"><defs><style>@font-face {{font-family:Montserrat;src:url(../assets/Montserrat.ttf)}}</style></defs><rect width="1080" height="1920" fill="{C["background"]}"/>']
for el in C['elements']:
 text(d,el['text'],el['y'],el['size'],el['weight'],el['color']);svg.append(f'<text x="540" y="{el["y"]}" text-anchor="middle" dominant-baseline="hanging" font-family="Montserrat,sans-serif" font-size="{el["size"]}" font-weight="{el["weight"]}" fill="{el["color"]}">{html.escape(el["text"])}</text>')
bg.alpha_composite(layer);bg.resize((W,H),Image.Resampling.LANCZOS).save(R/'end-card/End_Card.png');layer.resize((W,H),Image.Resampling.LANCZOS).save(R/'end-card/type-overlay.png');svg.append('</svg>');(R/'end-card/End_Card.svg').write_text('\n'.join(svg));(R/'project/text-bounds.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print('Assets checked: monochrome and safe bounds; lowest text',max(x['y']+x['height'] for x in checks))
