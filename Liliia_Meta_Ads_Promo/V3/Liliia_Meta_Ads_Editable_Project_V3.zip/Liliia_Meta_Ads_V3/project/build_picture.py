from pathlib import Path
import json,hashlib,subprocess
R=Path(__file__).resolve().parents[1];e=json.loads((R/'project/design.json').read_text());sig=hashlib.sha256((json.dumps(e['picture_edit'],sort_keys=True)+'sequential-v3.1').encode()).hexdigest();out=R/'intermediates/working-picture.mov';stamp=out.with_suffix('.sha256')
if out.exists() and stamp.exists() and stamp.read_text()==sig:print('Working picture cache valid');raise SystemExit
p=e['picture_edit'];a=p['keyboard'];b=p['notes'];ca=a['crop'];cb=b['crop'];src=str(R/e['source']);parts=[(0,216,'setpts=N/(30*TB),setsar=1'),(216/30,36,f'setpts=PTS-STARTPTS,crop={ca[0]}:{ca[1]}:{ca[2]}:{ca[3]},scale=1080:1920,setsar=1'),(252/30,80,f"setpts=PTS-STARTPTS,trim=duration=2,crop={cb[0]}:{cb[1]}:x='{cb[2]}':y={cb[3]},scale=1080:1920,setpts=N/(22.5*TB),fps=30,setsar=1"),(332/30,119,'setpts=N/(30*TB),setsar=1')]
for i,(start,n,vf) in enumerate(parts):
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(start),'-threads','1','-i',src,'-an','-vf',vf,'-filter_threads','1','-frames:v',str(n),'-r','30','-fps_mode','cfr','-c:v','libx264','-preset','veryfast','-crf','17','-threads','2',str(R/f'intermediates/picture-{i}.mov')],check=True)
 q=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-of','json',str(R/f'intermediates/picture-{i}.mov')]));assert int(q['streams'][0]['nb_frames'])==n
 print('Picture part',i,n,'frames',flush=True)
f=R/'intermediates/picture-concat.txt';f.write_text(''.join("file '"+str(R/f'intermediates/picture-{i}.mov')+"'\n" for i in range(4)));subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(f),'-c:v','copy','-an',str(out)],check=True);stamp.write_text(sig)
